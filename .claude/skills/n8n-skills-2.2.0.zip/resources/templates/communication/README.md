# Communication & Collaboration

Email, WhatsApp, Telegram, Slack automation

Total: 1 templates

## Template List

- [Personal Life Manager with Telegram, Google Services & Voice-Enabled AI](./8237-personal-life-manager-with-telegram-google-services-voice-en.md) - 34,342 views
