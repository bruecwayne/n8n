# Miscellaneous Nodes - Node Collection

This file contains complete information for 1 nodes.

## Table of Contents

- [EvaluationTrigger.node.ee.js](#evaluationtriggernodeeejs)

---

## EvaluationTrigger.node.ee.js

## Basic Information

- Node Type: `nodes-base.`
- Category: misc
- Package: n8n-nodes-base

### JSON Configuration Examples

#### Basic Configuration
```json
{
  "name": "EvaluationTrigger.node.ee.js",
  "type": "nodes-base.",
  "typeVersion": 1,
  "position": [
    250,
    300
  ],
  "parameters": {}
}
```
