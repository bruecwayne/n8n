# Organization Nodes

Total: 4 nodes (high-priority: 0, other: 4)

## Other Nodes

The following nodes are merged into a single file:

- [View Complete List](./organization-merged.md) - Contains 4 nodes

### Complete Node List

- No Operation, do nothing
- Simulate
- Split In Batches
- Wait
